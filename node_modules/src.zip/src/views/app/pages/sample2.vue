<template>
    <div class="main-content">
      <MainHeader>
        
      </MainHeader>
  
      <main>
        <router-link to="/sample">sample Page</router-link><br>
        <div class="main">
          <div class="content">
            <div class="search-bar">
                <img src="/images/search-line.png" alt="" width="20px" height="20px" style="position: relative;">
                <div class="search">
                  <p id="search-text">Search leads</p>
                </div>
            </div>
            <div class="filter">
                <img src="/images/Filter.png" alt="" width="40px" height="40px" style="position: relative;">
              </div>
          </div>
         <div class="content-date">
          <div class="contentdate-items">
            <div class="text-date1">Wednesday, Oct 04</div>
            <div class="btn-date">
              <div class="text-date2">Today</div>
            </div>
          </div>
         </div>
         <div class="car-wash">
                  <b-button class="content-car">
            <div class="contentcar-items">
              <div class="car-wash-text">Car wash</div>
              <div class="car-wash-name">Octopus Car Spa</div>
            </div>
            <div class="car-wash-time">
              <div class="car-period">
                <div class="car-new">New</div>
              </div>
              <div class="car-time">
                1 Hour ago
              </div>
            </div>
           </b-button>
           </div>
           <div class="car-wash">
                  <b-button class="content-car">
            <div class="contentcar-items">
              <div class="car-wash-text">Car wash</div>
              <div class="car-wash-name">JP Car & Bike Wash</div>
            </div>
            <div class="car-wash-time">
              <div class="car-period">
                <div class="car-new">New</div>
              </div>
              <div class="car-time">
                1 Hour ago
              </div>
            </div>
           </b-button>
           </div>
           <div class="car-wash">
                  <b-button class="content-car">
            <div class="contentcar-items">
              <div class="car-wash-text">Car wash</div>
              <div class="car-wash-name">Steamex Car Wash</div>
            </div>
            <div class="car-wash-time">
              <div class="car-period">
                <div class="car-new">New</div>
              </div>
              <div class="car-time">
                1 Hour ago
              </div>
            </div>
           </b-button>
           </div>
           <div class="car-wash">
                  <b-button class="content-car">
            <div class="contentcar-items">
              <div class="car-wash-text">Car wash</div>
              <div class="car-wash-name">Hermosa Car spa & cafe</div>
            </div>
            <div class="car-wash-time">
              <div class="car-period">
                <div class="car-new">New</div>
              </div>
              <div class="car-time">
                1 Hour ago
              </div>
            </div>
           </b-button>
           </div>
           <div class="car-wash">
                  <b-button class="content-car">
            <div class="contentcar-items">
              <div class="car-wash-text">Car wash</div>
              <div class="car-wash-name">JP Car & Bike Wash</div>
            </div>
            <div class="car-wash-time">
              <div class="car-period">
                <div class="car-new">New</div>
              </div>
              <div class="car-time">
                1 Hour ago
              </div>
            </div>
           </b-button>
           </div>
           <div class="car-wash">
                  <b-button class="content-car">
            <div class="contentcar-items">
              <div class="car-wash-text">Car wash</div>
              <div class="car-wash-name">JP Car & Bike Wash</div>
            </div>
            <div class="car-wash-time">
              <div class="car-period">
                <div class="car-new">New</div>
              </div>
              <div class="car-time">
                1 Hour ago
              </div>
            </div>
           </b-button>
           </div>
        
  
        <div class="show-more">
          <div class="show-group">
            <div class="show-items">
              <div class="show-content">
                <div class="show-more-text">Show more</div>
              </div>
              <div class="arrow-png">
                <img src="/images/Arrow-down.png" alt="" width="24px" height="24px" style="position:relative;margin-left: 98%;margin-top: -30px;">
              </div>
            </div>
          </div>
        </div>
        
        <div class="yesterday">
          <div class="yesterday-date">
            Tuesday, Oct 03
          </div>
        </div>
  
        </div>
      </main>
      <MainFooter>
  
      </MainFooter>
    </div>
  </template>
  <script>
  import MainHeader from '/src/views/app/pages/header'
  import MainFooter from '/src/views/app/pages/footer'
  export default{
    metaInfo: {
      title: "Lead Finder"
    },
    components:{
      MainHeader,MainFooter
    },
    data(){
      return {
  
      };
    }
  };
  </script>
  <style scoped>
  
  @import './style/style.css';
    
  </style>