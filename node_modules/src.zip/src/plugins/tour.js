import Vue from 'vue'
import VueTour from 'vue-tour'
 
require('vue-tour/dist/vue-tour.css')
 
