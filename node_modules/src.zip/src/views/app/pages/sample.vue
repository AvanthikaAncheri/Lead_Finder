<template>
    <div class="main-content">
      <MainHeader>
        
      </MainHeader>
  
      <main>
        <router-link to="/account"></router-link>
        <div class="ld-main" v-if="is_load">
           <div class="main-load">
             <div class="ld-section1">
               <div class="ld-content1"></div>
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
             <div class="ld-section2">
                 <div class="ld-content2">
                    <div class="ld-content21"></div>
                    <div class="ld-content22"></div>
                 </div>
                <div class="ld-content23">
                   <div class="ld-content231"></div>
                   <div class="ld-content232"></div>
                   <div class="ld-content24"></div>
                </div>
                
             </div>
  
           </div>
        </div>
        <div class="main" v-else> 
          <div class="content-date">
          <div class="contentdate-items">
            <div class="text-date1">Wednesday, Oct 04</div>
            <div class="btn-date">
              <div class="text-date2">Today</div>
            </div>
          </div>
         </div>
         <div class="car-wash">
           <b-card class="content-car">
            <div class="card-body" v-b-modal.modal-1>
              <div class="contentcar-items">
                <b-card-text class="car-wash-text">Car wash</b-card-text>
                <b-card-text class="car-wash-name">Octopus Car Spa</b-card-text>
              </div>
              <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                </div>
                      
            </div>
           </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">JP Car & Bike Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Steamex Car Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Hermosa Car Spa & Cafe</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">JP Car & Bike Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">JP Car & Bike Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Steamex Car Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Steamex Car Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Hermosa Car Spa & Cafe</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Hermosa Car Spa & Cafe</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Hermosa Car Spa & Cafe</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
  
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Steamex Car Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">JP Car & Bike Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">JP Car & Bike Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">JP Car & Bike Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">JP Car & Bike Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
         <div class="car-wash">
            <b-card class="content-car">
                  <div class="card-body">
                      <div class="contentcar-items">
                          <b-card-text class="car-wash-text">Car wash</b-card-text>
                          <b-card-text class="car-wash-name">Steamex Car Wash</b-card-text>
                      </div>
                      <div class="car-wash-time">
                           <b-button class="car-period">
                                 <div class="car-new">New</div>
                            </b-button>
                           <div class="car-time"> 1 Hour ago</div>
                      </div>
                  </div>
            </b-card>
         </div>
        </div>
      </main>
      <MainFooter>
  
      </MainFooter>
      <!-- modals -->
      <div>
        
        <b-modal id="modal-1" class="modal-1" title="" hide-header hide-footer>
          <header id="modal-header" class="modal-header">
                  <div class="lead">
                    <h5 id="modal-title">Lead Details</h5>
                  </div> 
                  <div class="modal0-close">
                      <button class="modal0-close-btn" aria-label="Close" @click="$bvModal.hide('modal-1')">
                          <img src="/images/Close.png" alt="" width="24px" height="24px" style="position: relative;">
                      </button>
                  </div>
            </header>
            <div class="modal-content">
              <div class="modal-details">
                <div class="modal-new">
                      <div class="new-text">New</div>
                      <div class="arrow-down"><img src="/images/arrow-down-s.png" alt="" width="24px" height="24px" style="position: relative;"></div>
                  </div>
                </div>
                <div class="modal-car">
                      <div class="modal-car-text">Octopus Car Spa</div>
                      <div class="modal-car-content">
                        <img src="/images/Map.png" alt="" width="20px" height="20px" style="position: relative;">
                        <div class="modal-car-details">8B, Summer sandal canal Road Thrikkakkara, Kochi</div>
                      </div>
              </div>
              <div  id="modal-car-contact">
                      <div  id="modal-car-wash">
                          <img src="/images/Briefcase.png" alt="" width="20px" height="20px" style="position: relative;">
                          <div class="modal-wash-text">Car Wash</div>
                      </div>
                      <div  id="modal-car-mobile">
                        <img src="/images/phone-line.png" alt="" width="20px" height="20px" style="position: relative;">
                        <div class="modal-mobile-text">+91974689545</div>
                      </div>
                      <div  id="modal-email">
                        <div class="modal-car-email">
                                    <img src="/images/Email.png" alt="" width="20px" height="20px" style="position: relative;">
                                  <div class="modal-email-text">Not available</div>
                                  <div class="modal-add-email">Add Email</div>
                          </div>
                      </div>
                      <div  id="modal-car-web">
                        <img src="/images/Web.png" alt="" width="20px" height="20px" style="position: relative;">
                          <div class="modal-web-text">www.octopuscarspaservice.com</div>
                      </div>
              </div>
              <div class="modal-buttons">
                <div class="modal-button1" v-b-modal.modal-2 v-if="is_note">
                  <img src="/images/addicon.png" alt="" width="20px" height="20px" style="position: relative;">
                            <div class="add-text">Add Note</div>
                </div>
                <div class="modal-button2" v-b-modal.modal-3 v-else-if="is_log">
                  <img src="/images/log.png" alt="" width="20px" height="20px" style="position: relative;">
                  <div class="log-activity">Log Activity</div>
                  </div>
              </div>
  
            </div>
        </b-modal>
          
          <b-modal id="modal-2" title="" hide-header hide-footer>
            <div class="modal-2">
              <header class="modal2-content">
              <div class="modal2-header">
                <button type="button" class="modal2-header-content" aria-label="Close" @click="$bvModal.hide('modal-2')">
                      <img src="/images/Arrow-back.png" alt="" width="24px" height="24px" style="position: relative;">
                </button>
                  <div class="modal2-header-text">Note</div>
              </div>
              <div class="modal2-close">
                <button class="modal2-close-btn" aria-label="Close" @click="$bvModal.hide('modal-2')">
                  <img src="/images/Close.png" alt="" width="24px" height="24px" style="position: relative;">
                </button>
              </div>
            </header>
            <div class="modal2-description">
              <div class="description-text-box">
                <div class="description-text">Enter Description</div>
              </div>
              <div class="add-note">Add your Note</div>
            </div>
            <div class="button-save-note">
              <button class="log-save-activity">
                        <div class="log-save-text">Save Note</div>
                  </button>
            </div>
            
            </div>
          </b-modal>
          
          <b-modal id="modal-3" title="" hide-header hide-footer>
              <div class="modal3-main">
                <div class="modal3-container">
                  <header class="modal3-items">
                    <div class="modal3-header">
                      <button type="button" class="modal3-arrow" aria-label="Close" @click="$bvModal.hide('modal-3')">
                        <img src="/images/Arrow-back.png" alt="" width="24px" height="24px" style="position: relative;">
                      </button>
                      <div class="modal3-headertext">
                        Log Activity
                      </div>
                      <div class="modal3-close">
                          <button type="button" class="modal3-butn" aria-label="Close" @click="$bvModal.hide('modal-3')">
                            <img src="/images/Close.png" alt="" width="24px" height="24px" style="position: relative;">
                          </button>
                      </div>
                    </div>
                  </header>
                  <div class="modal-log-content">
                    <div class="log-activity-text">Add your log Activity here</div>
                  </div>
                      <div class="log-buttons">
                        <button type="button" class="log-butn1">
                          <div class="logbutn-text">Call</div>
                        </button>
                        <button type="button" class="log-butn1">
                          <div class="logbutn-text">Mail</div>
                        </button>
                      </div>
                      <div class="modal-log-description">
                        <div class="log-description-box">
                          <div class="log-description-text">Enter Activity</div>
                        </div>
                        <div class="log-add-description">Add your Activity</div>
                      </div>
                    </div>
                    <div class="logdate-time-butn">
                    <button type="button" class="logdate-btn1">
                      <div class="log-date-outline">
                        <div class="log-date-text">Date</div>
                      </div>
                      <input type="date"  id="log-date">
                    </button>
                    <button type="button" class="logdate-btn2">
                      <div class="log-date-outline">
                      <div class="log-date-text">Time</div>
                      </div>
                      <input type="time"  id="log-time">
                    </button>
                    </div>
                    <button class="log-save-activity">
                          <div class="log-save-text">Save Activity</div>
                    </button>
              </div>
            </b-modal>
      </div>
    </div>
  </template>
  <script>
  import MainHeader from '/src/views/app/pages/header'
  import MainFooter from '/src/views/app/pages/footer'
  export default{
    metaInfo: {
      title: "Lead Finder"
    },
    components:{
      MainHeader,MainFooter
    },
    data() {
      return {
        is_load : true,
        is_note: true,
        is_log:true,
      };
    },
    mounted(){
      var self = this
      setTimeout(function(){
        self.is_load = false
      },5000)
    }
    // function showModal(modal){
    //   if(is_note=true){
    //         modal.dialog_alert("modal-2");
    //   }
    //   else if(is_log=true){
    //     modal.dialog_alert("modal-3");
    //   }
    //   else{
    //     modal.dialog_alert("modal-1");
    //   }
    }; 
  
  </script>
  <style scoped>
  
  @import './style/style.css';
    
  </style>
