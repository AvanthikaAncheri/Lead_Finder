<template>
    <div class="main-content">
       <header>
        <div class="header">
          <div class="crm-header">
            <img src="/images/arrow-left-s-line.png" width="32px" height="32px" id="crm-icon">
            <h1 id="crm">Accounts</h1>
          </div>
        </div> 
  
      </header>
    </div>
  </template>