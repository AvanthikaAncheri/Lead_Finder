<template>
  <div>
    <div style="margin-top: 100px;"></div>
    <div class="footer footer-home">
      <div class="footer-content">
          <img src="/images/home-home.png" alt="" width="24px" height="24px" style="position: relative;">
          <div class="footer-text">Home</div>
      </div>
      <div class="footer-content">
          <img src="/images/search-line.png" alt="" width="24px" height="24px" style="position: relative;">
          <div class="footer-text1">Find Leads</div>
      </div>
      <div class="footer-content">
          <img src="/images/CRM.png" alt="" width="24px" height="24px" style="position: relative;">
          <div class="footer-text1">CRM</div>
      </div>
      <div class="footer-content">
          <img src="/images/mail-box.png" alt="" width="24px" height="24px" style="position: relative;">
          <div class="footer-text1">Marketing</div>
      </div>
    </div>
  </div>
</template>

<style scoped>
@import './style/home.css';
</style>